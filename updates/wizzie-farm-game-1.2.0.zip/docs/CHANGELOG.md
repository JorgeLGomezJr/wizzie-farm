# Wizzie Farm — Changelog

## v1.2.0 — "Deck & Dungeon" (Jorge's v1.1 feedback)
Built by nine parallel studio workstreams under `docs/V1.2-CONTRACT.md` (§1–10), merged, integration-tested and independently reviewed.
**Duels**
- Spell casts take ~1.5× longer (longer wind-up, creature presence and impact hold; the strike stays fast). "Fast combat animations" keeps the v1.1 timing.
- Nameplates above every enemy (name, level, health, school, elite ★ / boss ♛, charms/wards); HUD panels ordered exactly as the enemies stand and re-sorted when the camera moves; model/plate/panel clicks target the same enemy.
- Pip Surge: a chance to gain 2 pips in one round ("+2 Pips!"). Power Pip: chance each new pip is a bright pip worth 2.
- Every spell card has its own painted illustration (91 cards).
**Decks (W101-style)**
- Deck items: Apprentice, Journeyman, Adept, Luminary (shop), Orrery (dungeon), Artificer (crafted), each with size, copy limits, other-school limit and a Spell Scroll sideboard. New two-page Spellbook & Deck book: click or drag to copy cards in, auto-fill, multiple saved decks.
**End-game (level 10)**
- The Hollow Orrery: a repeatable level-10 dungeon (3 sealed rooms, Orrery Sentinel, Warden Morrow, the Starless Archon), unlocked after the story via Aldric's quest.
- Boss spells: the Archon's first clear teaches a 4-pip area spell per school (Ascendant Quake / Tide / Flare).
- Gear tiers T1/T2/T3 for Starbound (dungeon), Starwalker Boots (Nyx re-fight) and Artificer (crafted only): school-specific in every slot, random-school drops, set bonuses, upgrades and salvage at Tamsin Gearwright (new crafter in Lanternmere).
- Gear-over-levels rule (balance-sim): a perfect level 10 ≥ a bad-gear level 20 (≤ 1.25×); projected scaling to level 60.
- Level-up screen shows health and mana gained.
**Account & app**
- Up to 3 wizards per account ("Choose your Wizard" with live 3D previews), export/import, typed-name delete. Old saves move into slot 1 automatically (old save kept as a backup).
- Shared bank (Lanternmere Vault) to move gear, mounts, decks and reagents between your wizards.
- Windows desktop app (Electron) with file saves + 5 backups and self-updates (GitHub Releases once configured, or a drop-in `updates` folder).
**World, art & audio**
- Every NPC and boss is voiced (Kokoro neural TTS, 40+ voices); Voices on/off + volume in Settings.
- New art: 5 dungeon enemies, vault zone, 9 props, Artificer/Starbound/Starwalker gear looks with T1–T3 escalation, Orrery Strider mount.
**Saves**: account format v4 (3 slots + bank); per-wizard migration adds deck items. v1.1 saves upgrade automatically.

## v1.1.0 — "Gear & Glory" (Jorge's first-play feedback)
Built by six parallel studio workstreams (render, props, characters, creatures, VFX/duels, systems/UI) under `docs/V1.1-CONTRACT.md`, then merged, integration-tested and reviewed.
**Spell cinematics (Wizard101-style)**
- Every spell plays as a short cinematic: wand twirl, the spell card rises over the caster, a school sigil flares, the camera cuts, an original summoned creature performs the attack, big impact with shake/flash/bloom, camera returns.
- 48 cinematics: every player attack (e.g. Spark Newt, Ember Moth, Gale Hawk, Blaze Fox, Skyrend Drake, Phoenix; Pebble Golem, Stone Boar, Golem Fist, Quake Ram, Stone Titan; Water Sprite, Undertow, Wave Serpent, Moon Tide, Maelstrom, Leviathan; Sunburst), heal fairies, blades, traps, shields, absorbs, weaknesses, and all Hollow enemy spells incl. boss signatures (Night Terror, Eclipse, Captain's Cleave…).
- Click / Space skips to the hit. Settings: Spell animations Cinematic / Quick (fast combat and reduce motion respected).
- Duel entry: the ring draws itself, enemies taunt; cards are dealt in; enemies collapse and dissolve when defeated; victory/defeat poses.
**Graphics**
- New render pipeline: HDR bloom (glows really glow), MSAA, colour grading per zone, full-resolution rendering, sharper shadows. Graphics tiers Ultra / High / Medium / Low (Auto steps down if slow).
- Painted textured ground (cobbles, dirt, flagstones, leaf litter, ember veins), dense wind-swept grass and flowers, painted skies with clouds, sun/moon/eclipse and distant mountains, ambient particles (pollen, fireflies, leaves, embers), new portals and wisps, water.
- All 30 props re-authored at much higher detail (layered trees, timber houses with shingled roofs, carved ruins, three-tier fountain…) with a painterly surface finish — and fewer draw calls than v1.0.
- All 13 enemies reworked to look far more menacing (brows, fangs, horns, glowing runes, smoke/ember auras, rim light); bosses ~40% bigger.
**Gear & rarity**
- Five rarities: Common, Uncommon, Rare, Epic, Legendary. 164 gear pieces across four zone tiers; 13 unique boss legendaries.
- Every enemy can drop gear (~36% per normal fight, ~83% elite, bosses always — rare or better).
- Elite enemies (gold ★ names) in every combat zone: harder, better loot.
- Gear changes your look: 10 hat styles, 6 robes, 4 boots (wizards now have feet), 7 wands, 3 amulets; rarity adds trim, glowing gems, runes and (legendary) animated auras.
- Backpack redesign: live 3D wizard preview, rarity frames, stat-compare tooltips, filters/sorting, NEW badges; "Sell all Common" at vendors; rarity reveal on legendary/epic drops.
**Mounts**
- Press R to ride. Pony, horses, Lumen Warhorse from Hollis Brightmane's new Brightmane Stables in Lanternmere; side quest "A Steed of Your Own" gives a free pony; rare boss/elite mounts: Mossback, Thornstag, Emberhoof, Nightmare of the Gloam. +25–60% speed. Duels dismount and remount you automatically.
**Animation**
- Wizards: bouncy run, wand-twirl casts, big summon cast, hit reactions, victory cheer, defeat slump, riding, talking gestures, idle fidgets, flowing robes/hats.
- Enemies: taunt, aggressive duel stance, prowl, lunge casts, collapse-and-dissolve defeat.
**Balance**
- Bosses retuned for the stronger gear (at-level win rates 67–89% for Tidecaller/Emberstrike, tank Stoneward ~98%). Shop prices rebalanced for the extra gear income.
**Polish (independent creative-director + lead-programmer reviews)**
- Duel HUD fades out while a cinematic plays; smarter duel camera keeps your wizard and boss heads clear of the UI and hides scenery in the way; deliberate victory/defeat shots; cleaner results screen; elite ★ panels; per-school blade/trap/shield effects; softer impact flashes; dimmer duel ring with your school sigil.
- Dialogue close-ups on NPCs, mounted camera that shows your horse, hoof dust, see-through scenery when a tree blocks your view, nameplates that never cover menus, denser cobblestones, warmer forest paths, less haze in Mosslight, bluer skies.
- Fixes: inside-out feathered hat and mushroom caps, name plates stretched after respawn, gear equipped from the victory screen now shows immediately, owned mounts don't drop again, riders keep their size on every mount, wider collision while riding, graphics context-loss recovery.
**Saves**: format v3 (mounts, NEW badges, cinematics setting). v1.0 saves upgrade automatically with gear intact.

## v1.0.0 — Chapter One, polished (studio review sprint)
Built and reviewed with the Claude Code Game Studios roles (design, narrative, level, art, audio, programming, QA, creative-director review).
**Combat feel**
- Bright pips: some pips arrive "bright" and pay double for your own school and Lumen spells.
- Enemy school affinities: monsters are weak to or resist certain schools (shown on their duel panel).
- Burns now keep the blades/traps that were active when cast.
- Bosses have intros, a 50%-health phase (with a free spell and an aura), opening wards, and "freed" lines on victory.
- Spell cards show their real, boosted numbers in gold when blades/traps/weaknesses apply; tooltip lists every modifier.
- New spell visuals per school: bolts, meteors, Golem Fist, Wave Serpent, lightning, swarms, and summoned 5-pip creatures (Phoenix, Stone Titan, Leviathan, Sun, Shadow Raven). Cast sigils under the caster.
- Duel camera moved to a 3/4 view; world name tags hidden during duels; regular mobs only shout the first time you meet them.
**Progression & economy**
- Learn new spells from your school trainer (W101 style). Training points (L2/4/6/8) buy other schools' utility spells.
- Crafting at Wren and Pip: potions, Spell Scrolls and amulets from reagents.
- Rare/epic gear, per-school boss drops, Spell Scrolls re-roll if they're your own school.
- Level-9 Luminary gear tier. Starter gear from the first Mosslight quests.
**World & story**
- Hub renamed Lanternmere (original IP). New side quest "Relight the Path" (relight lanterns with E).
- Zones visibly heal after their boss is freed. South Gate plaza reserved for future zones.
- In-world ending; cliffhanger lives in lore.js.
**Fixes** (from lead-programmer review): player model could vanish after a defeat; Spell Scrolls were unusable; panels lost clicks; minimap rotated 180°; E taps missed; Enter re-opened dialogs; memory leaks over long sessions; duel UI showed results before animations; save import/migration hardening; flee/charm-cap feedback; keyboard handling for overlays.


## v0.1.0 — Chapter One: The Black Feathers (first playable, internal)
- 3 schools: Stoneward (tank), Tidecaller (balanced), Emberstrike (damage).
- Levels 1–10 (data-driven cap, ready for 11+).
- 4 zones in 3D: Lanternmere (hub), Mosslight Path (L1–3), Whisperwood (L3–6), Ashen Ruins (L6–10).
- Turn-based card duels: pips, mana, accuracy/fizzles, blades, traps, shields, weakness, absorbs, burns, heals over time, drains, area spells, spell scrolls; live damage preview showing how blades/traps change each spell.
- 13 enemy types incl. 4 bosses (Grubnak, Thornmaw, Captain Vex, Nyx the Herald) with distinct AI personalities.
- 22 quests (17 main story + 5 side), 10 NPCs, Good (Lumen Order) vs Evil (Hollow Court).
- Loot: gold, reagents, gear (5 slots), potions, spell scrolls. Shops.
- Spellbook deck editor, backpack/equipment, quest log & tracker, minimap, wisps, autosave + export/import.
- Synthesized sound effects and adaptive ambient music per zone.
