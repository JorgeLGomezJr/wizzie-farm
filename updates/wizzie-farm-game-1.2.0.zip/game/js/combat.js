// =====================================================================
//  WIZZIE FARM — COMBAT RULES ENGINE  (WF.Battle)
//
//  Implements: docs/ARCHITECTURE.md -> "combat.js" and "Rules (combat)".
//
//  This file is PURE LOGIC. It never touches THREE.js or the web page.
//  It only answers "what happens?" and hands back a list of EVENTS that
//  combatView.js turns into animations, sounds and numbers on screen.
//  Because of that it also runs inside Node, which is how the automated
//  tests in tests/combat.test.js check the rules.
//
//  Quick tour of a duel:
//    var b = new WF.Battle({ player: {...}, enemies: ['hollow_sprite'] });
//    b.start();                          -> round 1: pips + draw a hand
//    b.playerTurn({ type: 'cast', uid: b.hand[0].uid, target: 1 });
//         -> the player acts, every living enemy acts, the next round
//            begins (damage/heal over time ticks, +1 pip, refill hand).
//    ...repeat until b.result is 'win', 'lose' or 'flee'.
//
//  All numbers (pips, hand size, charm limits, spell values, enemy
//  stats) come from game/data/*.js. The only numbers in this file are
//  the enemy "personality" defaults in AI_DEFAULTS below, and those can
//  be overridden from data via WF.data.aiProfiles (see notes there).
//
//  v0.2 additions (docs/ARCHITECTURE.md -> "v0.2 CONTRACT ADDENDUM"):
//    * BRIGHT PIPS  every new pip may be "bright" (progression.
//      brightPipChance(level); bosses 0.3 via enemies.js brightChance).
//      A bright pip pays 2 of a spell's pip cost for spells of the
//      caster's own school (or Lumen) and 1 for anything else. Mana
//      cost is always card.pips. Combatants carry `bright` (how many of
//      their `pips` are bright); pip events carry it too.
//    * AFFINITY     enemies.js `affinity: { school: f }` multiplies every
//      hit of that school by (1 - f): f > 0 resists, f < 0 is a weakness.
//    * DOT SNAPSHOT a burn's per-round tick = dot.amt x the same charm /
//      ward / damage / resist / affinity multiplier as its instant hit.
//    * BOSS PHASES  enemies.js `phases: [{ at, say, cast, once }]` emit
//      { t:'phase', who, idx, say } (+ an optional free instant cast).
//    * DISPLAY SNAPSHOTS every event gets `snap` (one entry per
//      combatant, taken right AFTER that event) so the duel view can
//      animate the round step by step; 'draw' events also get `hand`.
//      new WF.Battle({ ..., snapshots: false }) turns this off (the
//      balance simulator does that for speed).
//
//  v1.2 additions (docs/V1.2-CONTRACT.md §2.1):
//    * POWER PIP    player.brightPip (0..1, gear) is ADDED to the bright-
//      pip chance, total capped at progression.brightPipCap (0.60).
//    * PIP SURGE    player.pipSurge / enemies.js `pipSurge` (0..1, capped at
//      progression.pipSurgeCap 0.35): at the start of every round from
//      round 2 on, a chance to gain ONE extra normal pip (2 pips in that
//      round), never above maxPips. The pips event then has surge: true.
//      The roll only happens for combatants with pipSurge > 0, so duels
//      without the stat use exactly the same random numbers as v1.1.
// =====================================================================
(function (root) {
  'use strict';

  // Works in the browser (window) and in Node tests (global).
  root.WF = root.WF || { data: {} };
  var WF = root.WF;

  // Spell types that hurt somebody (used by the AI and previews).
  var ATTACK_TYPES = { damage: true, aoe: true, dot: true };
  var MINUS = '−'; // the proper minus sign "−" for labels

  // -------------------------------------------------------------------
  //  ENEMY PERSONALITIES (ai: 'basic' | 'healer' | 'buffer' | 'boss')
  //
  //  The AI gives every spell it can afford a SCORE measured in
  //  "damage points" (how much it helps, roughly), multiplies it by the
  //  personality weights below, then picks randomly with better spells
  //  being much more likely. That keeps enemies sensible but not robotic.
  //
  //    attack   - weight on damage spells
  //    setup    - weight on blades / traps (buffing its own next hit)
  //    debuff   - weight on weakness (shrinking the player's next hit)
  //    defend   - weight on shields / absorbs
  //    heal     - weight on heals
  //    healAt   - only heal when an ally is below this fraction of HP
  //    maxHeals - most heal spells it will cast in one duel (stops endless
  //               heal stalemates; keeps healers beatable)
  //    defendCooldown - rounds before it will put up another shield/absorb
  //               (so the player always gets windows to hit hard)
  //    saveBias - how willing it is to skip a turn to afford a bigger spell
  //    sharpness- higher = picks the best option more reliably (1 = loose)
  //    minRel   - ignore options scoring below this fraction of the best
  //    finisher - bonus multiplier for a spell that will surely kill you
  //    savesPips- (boss) stores pips for its biggest spell
  //    maxIdle  - (boss) most turns in a row it will just wait
  //
  //  To tune without touching code, add to a data file e.g.
  //    WF.data.aiProfiles = { boss: { maxIdle: 1 } };
  // -------------------------------------------------------------------
  var AI_DEFAULTS = {
    basic:  { attack: 1.0, setup: 0.6, debuff: 0.6, defend: 0.5, heal: 0.8, healAt: 0.30, maxHeals: 1, defendCooldown: 2, saveBias: 0.8,  sharpness: 2, minRel: 0.25, finisher: 3, savesPips: false, maxIdle: 0 },
    healer: { attack: 0.8, setup: 0.5, debuff: 0.7, defend: 0.7, heal: 1.8, healAt: 0.45, maxHeals: 3, defendCooldown: 2, saveBias: 0.6,  sharpness: 2, minRel: 0.25, finisher: 3, savesPips: false, maxIdle: 0 },
    buffer: { attack: 0.9, setup: 1.6, debuff: 1.4, defend: 0.6, heal: 0.8, healAt: 0.30, maxHeals: 1, defendCooldown: 2, saveBias: 0.9,  sharpness: 2, minRel: 0.25, finisher: 3, savesPips: false, maxIdle: 0 },
    boss:   { attack: 1.0, setup: 1.3, debuff: 1.2, defend: 0.8, heal: 1.0, healAt: 0.30, maxHeals: 2, defendCooldown: 2, saveBias: 1.0,  sharpness: 3, minRel: 0.30, finisher: 4, savesPips: true,  maxIdle: 2 }
  };

  // ---------------- small helpers ----------------
  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
  function pctText(p) { return (p >= 0 ? '+' : MINUS) + Math.abs(p) + '%'; }
  function matches(effect, card) { return effect.affects === 'any' || effect.affects === card.school; }
  function avg(card) { return ((card.min || 0) + (card.max || 0)) / 2; }
  // Events get their own copy so later changes (e.g. rounds ticking down)
  // don't alter what the animation code is reading.
  function copy(o) { var r = {}; for (var k in o) r[k] = o[k]; return r; }

  function copyAll(list) { var r = new Array(list.length); for (var i = 0; i < list.length; i++) r[i] = copy(list[i]); return r; }
  function schoolName(id) {
    var s = (WF.data && WF.data.schools && WF.data.schools[id]) || null;
    return (s && s.name) || (id ? id.charAt(0).toUpperCase() + id.slice(1) : '?');
  }

  // ===================================================================
  //  CONSTRUCTOR
  // ===================================================================
  function Battle(opts) {
    opts = opts || {};
    var data = WF.data || {};
    this.cards = data.cards || {};
    this.enemyDefs = data.enemies || {};
    this.prog = data.progression || {};
    this.rng = typeof opts.rng === 'function' ? opts.rng : Math.random;
    this.snapshots = opts.snapshots !== false;

    // Rule values (from progression.js)
    this.maxPips = this.prog.maxPips || 7;
    this.startPips = (this.prog.startPips != null) ? this.prog.startPips : 1;
    this.handSize = this.prog.handSize || 7;
    this.maxCharms = this.prog.maxCharms || 6;
    this.bossBrightChance = (this.prog.bossBrightChance != null) ? this.prog.bossBrightChance : 0.3;
    // v1.2 WS2: caps for the gear stats Power Pip (brightPip) and Pip Surge
    this.brightPipCap = (this.prog.brightPipCap != null) ? this.prog.brightPipCap : 0.60;
    this.pipSurgeCap = (this.prog.pipSurgeCap != null) ? this.prog.pipSurgeCap : 0.35;

    // AI personalities = defaults, overridden by WF.data.aiProfiles if present.
    this.aiProfiles = {};
    var over = data.aiProfiles || {};
    for (var k in AI_DEFAULTS) {
      var p = {}, d = AI_DEFAULTS[k], o = over[k] || {};
      for (var f in d) p[f] = (o[f] != null) ? o[f] : d[f];
      this.aiProfiles[k] = p;
    }

    // ---- the player combatant (always index 0) ----
    var pl = opts.player || {};
    var maxHp = pl.maxHp || pl.hp || 1;
    var level = pl.level || 1;
    var player = {
      idx: 0, name: pl.name || 'Wizard', isPlayer: true, enemyId: null,
      school: pl.school, level: level,
      hp: (pl.hp != null) ? pl.hp : maxHp, maxHp: maxHp,
      mana: (pl.mana != null) ? pl.mana : (pl.maxMana || 0), maxMana: pl.maxMana || pl.mana || 0,
      pips: 0, bright: 0, dmg: pl.dmg || 0, resist: pl.resist || 0, acc: pl.acc || 0,
      brightChance: this._withPowerPip((pl.brightChance != null) ? pl.brightChance : this._brightFor(level), pl.brightPip),
      pipSurge: this._surgeChance(pl.pipSurge),
      affinity: pl.affinity || null,
      charms: [], wards: [], dots: [], hots: [], absorb: 0, alive: true, boss: false
    };
    this.combatants = [player];
    this.player = player;

    // ---- enemies (index 1..n) ----
    var ids = opts.enemies || [];
    for (var i = 0; i < ids.length; i++) {
      var def = this.enemyDefs[ids[i]];
      if (!def) throw new Error('WF.Battle: unknown enemy id "' + ids[i] + '" (check enemies.js)');
      var lvl = def.level || 1;
      this.combatants.push({
        idx: i + 1, name: def.name || ids[i], isPlayer: false, enemyId: ids[i],
        school: def.school || 'hollow', level: lvl,
        hp: def.hp, maxHp: def.hp, mana: 0, maxMana: 0,
        pips: 0, bright: 0, dmg: def.dmg || 0, resist: def.resist || 0, acc: def.acc || 0,
        brightChance: (def.brightChance != null) ? def.brightChance : (def.boss ? this.bossBrightChance : this._brightFor(lvl)),
        pipSurge: this._surgeChance(def.pipSurge),
        affinity: def.affinity || null,
        phases: (def.phases || []).slice(), phaseDone: [],
        charms: [], wards: [], dots: [], hots: [], absorb: 0, alive: true, boss: !!def.boss,
        ai: this.aiProfiles[def.ai] ? def.ai : 'basic',
        deck: (def.deck || []).slice(),
        startPips: def.startPips,
        idleStreak: 0,         // boss: turns spent waiting in a row
        healsCast: 0,          // heals used this duel (see maxHeals)
        lastDefendRound: -99   // round it last cast a shield/absorb
      });
    }
    this.enemies = this.combatants.slice(1);

    // ---- the player's deck / hand ----
    this.deckCounts = {};
    this.drawPile = [];
    this.discardPile = [];
    this.hand = [];
    this._uid = 1;
    var deck = pl.deck || {};
    for (var id in deck) {
      if (!this.cards[id]) continue;          // skip unknown cards safely
      this.deckCounts[id] = deck[id];
      for (var n = 0; n < deck[id]; n++) this.drawPile.push(id);
    }
    this._shuffle(this.drawPile);

    // Spell Scrolls (treasure cards, `tcs`): a private copy; state.js subtracts b.tcsUsed afterwards.
    this.tcs = {};
    for (var t in (pl.tcs || {})) this.tcs[t] = pl.tcs[t];
    this.tcsUsed = {};

    this.round = 0;
    this.result = null;
    this.started = false;
    this.lastError = null;   // why the last playerTurn/discard was refused
    this.aiLog = [];         // debugging: every enemy decision with its scores
  }

  // Bright-pip chance for a level (progression.brightPipChance), 0..1.
  Battle.prototype._brightFor = function (level) {
    var f = this.prog.brightPipChance;
    return typeof f === 'function' ? clamp(+f(level) || 0, 0, 1) : 0;
  };
  // v1.2 WS2: Power Pip. Gear brightPip (0..1) adds to the base chance; the
  // total is capped at brightPipCap. A base that is already above the cap
  // (tests forcing brightChance 1) is kept as is: the cap only limits gear.
  Battle.prototype._withPowerPip = function (base, bonus) {
    base = clamp(+base || 0, 0, 1);
    bonus = clamp(+bonus || 0, 0, 1);
    if (!bonus) return base;
    return Math.min(base + bonus, Math.max(base, this.brightPipCap));
  };
  // v1.2 WS2: Pip Surge chance (0..1), capped at pipSurgeCap.
  Battle.prototype._surgeChance = function (v) {
    return clamp(+v || 0, 0, this.pipSurgeCap);
  };

  // ===================================================================
  //  EVENTS + DISPLAY SNAPSHOTS
  //  Every list returned by start()/playerTurn() is made here. Its push()
  //  stamps each event with `snap` = the state of every combatant right
  //  AFTER that event (index = combatant idx), and 'draw' events with the
  //  resulting `hand`. combatView.js uses these to show the round step
  //  by step instead of jumping to the end-of-round state.
  // ===================================================================
  Battle.prototype._events = function () {
    var self = this, ev = [];
    Object.defineProperty(ev, 'push', {
      enumerable: false, configurable: true, writable: true,
      value: function () {
        for (var a = 0; a < arguments.length; a++) {
          var e = arguments[a];
          if (self.snapshots) {
            e.snap = self._snap();
            if (e.t === 'draw') e.hand = self.hand.map(function (h) { return { uid: h.uid, cardId: h.cardId }; });
          }
          Array.prototype.push.call(this, e);
        }
        return this.length;
      }
    });
    return ev;
  };

  Battle.prototype._snap = function () {
    var out = new Array(this.combatants.length);
    for (var i = 0; i < this.combatants.length; i++) {
      var c = this.combatants[i];
      out[i] = {
        hp: c.hp, maxHp: c.maxHp, mana: c.mana, maxMana: c.maxMana,
        pips: c.pips, bright: c.bright, alive: c.alive, absorb: c.absorb,
        charms: copyAll(c.charms), wards: copyAll(c.wards), dots: copyAll(c.dots), hots: copyAll(c.hots)
      };
    }
    return out;
  };

  // ===================================================================
  //  PIPS  (normal + bright)
  // ===================================================================
  // Own school (or Lumen) = a bright pip is worth 2 for this card.
  Battle.prototype._isOwn = function (c, card) {
    return card.school === c.school || card.school === 'lumen';
  };
  // How many pips of cost `c` can pay for `card` right now.
  Battle.prototype._pipValue = function (c, card) {
    var normal = c.pips - c.bright;
    return this._isOwn(c, card) ? normal + 2 * c.bright : c.pips;
  };
  Battle.prototype._affordable = function (c, card) {
    return (card.pips || 0) <= this._pipValue(c, card);
  };
  // Pay a card's pip cost. Own-school: bright pips first (2 each, using a
  // normal pip for an odd remainder when possible); other schools: normal
  // pips first, bright pips count 1.
  Battle.prototype._payPips = function (c, card) {
    var cost = card.pips || 0, normal = c.pips - c.bright, useB = 0, useN = 0, rem;
    if (cost <= 0) return;
    if (this._isOwn(c, card)) {
      useB = Math.min(c.bright, Math.floor(cost / 2));
      rem = cost - 2 * useB;
      useN = Math.min(normal, rem);
      rem -= useN;
      if (rem > 0 && c.bright > useB) useB++;          // odd cost, no normal pip: a bright one overpays
    } else {
      useN = Math.min(normal, cost);
      useB = Math.min(c.bright, cost - useN);
    }
    c.pips = Math.max(0, c.pips - useN - useB);
    c.bright = Math.max(0, Math.min(c.pips, c.bright - useB));
  };
  // +1 pip (maybe bright). At the pip cap a bright roll upgrades a normal pip.
  Battle.prototype._gainPip = function (c) {
    var bright = c.brightChance > 0 && this.rng() < c.brightChance;
    if (c.pips < this.maxPips) { c.pips++; if (bright) c.bright++; }
    else if (bright && c.bright < c.pips) c.bright++;
  };
  // v1.2 WS2: Pip Surge. Called right after the round's normal pip (round
  // 2+ only). One extra NORMAL pip with chance c.pipSurge, never above
  // maxPips. No roll at all without the stat or at the pip cap, so the rng
  // sequence of duels without Pip Surge is unchanged. Returns true on a surge.
  Battle.prototype._surgePip = function (c) {
    if (!(c.pipSurge > 0) || c.pips >= this.maxPips) return false;
    if (this.rng() >= c.pipSurge) return false;
    c.pips++;
    return true;
  };

  // ===================================================================
  //  PUBLIC API
  // ===================================================================

  // Round 1: everyone gets their starting pips and the player draws a hand.
  Battle.prototype.start = function () {
    if (this.started) return [];
    this.started = true;
    var ev = this._events();
    this.round = 1;
    ev.push({ t: 'round', n: 1 });
    for (var i = 0; i < this.combatants.length; i++) {
      var c = this.combatants[i];
      var sp = clamp((c.startPips != null) ? c.startPips : this.startPips, 0, this.maxPips);
      c.pips = 0; c.bright = 0;
      for (var n = 0; n < sp; n++) this._gainPip(c);
      ev.push({ t: 'pips', who: c.idx, pips: c.pips, bright: c.bright });
    }
    // Opening phases (`at: 1`) fire right away, e.g. a boss that starts
    // the duel behind a ward.
    this._checkPhases(ev);
    if (!this.result) this._draw(ev);
    return ev;
  };

  // Can the player afford this card right now? (pips incl. bright pips, and mana)
  Battle.prototype.canCast = function (cardId) {
    var card = this.cards[cardId];
    if (!card) return { ok: false, reason: 'Unknown spell' };
    if (this.result) return { ok: false, reason: 'The duel is over' };
    var p = this.player;
    if (!this._affordable(p, card)) return { ok: false, reason: 'Not enough pips' };
    if (p.mana < (card.pips || 0)) return { ok: false, reason: 'Not enough mana' };
    return { ok: true, reason: '' };
  };

  // How many pips the player (or combatant `who`) can put toward this card
  // right now: normal pips + bright pips (x2 for own school / Lumen).
  Battle.prototype.pipValue = function (cardId, who) {
    var card = this.cards[cardId], c = this.combatants[who || 0];
    if (!card || !c) return 0;
    return this._pipValue(c, card);
  };

  // Fleeing is blocked when any boss is in the duel.
  Battle.prototype.canFlee = function () {
    for (var i = 0; i < this.enemies.length; i++) if (this.enemies[i].boss) return false;
    return !this.result;
  };

  // What WOULD happen if the player cast this card at this target?
  // Nothing is consumed. Returns { min, max, heal, acc, mods, dot, ... }.
  Battle.prototype.preview = function (cardId, targetIdx) {
    return this._preview(0, cardId, targetIdx);
  };

  // Throw a card from the hand away (it is not replaced until next round).
  Battle.prototype.discard = function (uid) {
    if (this.result) return false;
    for (var i = 0; i < this.hand.length; i++) {
      if (this.hand[i].uid === uid) {
        this.discardPile.push(this.hand[i].cardId);
        this.hand.splice(i, 1);
        return true;
      }
    }
    this.lastError = 'That card is not in your hand';
    return false;
  };

  // Resolve one WHOLE round, starting with the player's action:
  //   { type: 'cast', uid, target } | { type: 'tc', cardId, target }
  //   { type: 'pass' }              | { type: 'flee' }
  // Returns the ordered list of events. An invalid action (card not in
  // hand, can't afford it, flee vs a boss) returns [] and changes nothing;
  // b.lastError says why.
  Battle.prototype.playerTurn = function (action) {
    if (!this.started || this.result) return [];
    action = action || { type: 'pass' };
    this.lastError = null;
    var ev = this._events();
    var p = this.player;

    if (action.type === 'flee') {
      if (!this.canFlee()) { this.lastError = 'You cannot flee from a boss fight!'; return []; }
      this._end('flee', ev);
      return ev;
    } else if (action.type === 'cast') {
      var hi = -1;
      for (var i = 0; i < this.hand.length; i++) if (this.hand[i].uid === action.uid) { hi = i; break; }
      if (hi < 0) { this.lastError = 'That card is not in your hand'; return []; }
      var cardId = this.hand[hi].cardId;
      var cc = this.canCast(cardId);
      if (!cc.ok) { this.lastError = cc.reason; return []; }
      this.hand.splice(hi, 1);
      this.discardPile.push(cardId);              // cast or fizzled, it's spent
      this._cast(0, this.cards[cardId], action.target, ev);
    } else if (action.type === 'tc') {
      var tcId = action.cardId;
      if (!this.tcs[tcId] || this.tcs[tcId] <= 0) { this.lastError = 'You have no such spell scroll'; return []; }
      var ok = this.canCast(tcId);
      if (!ok.ok) { this.lastError = ok.reason; return []; }
      this.tcs[tcId]--;                            // used up even if it fizzles
      this.tcsUsed[tcId] = (this.tcsUsed[tcId] || 0) + 1;
      this._cast(0, this.cards[tcId], action.target, ev);
    } else {
      ev.push({ t: 'pass', who: p.idx });
    }
    if (!this.result) this._checkPhases(ev);

    // Enemies act in order (dead ones skip; stop as soon as it's decided).
    for (var e = 1; e < this.combatants.length && !this.result; e++) {
      if (this.combatants[e].alive) {
        this._enemyAct(e, ev);
        if (!this.result) this._checkPhases(ev);
      }
    }
    if (!this.result) this._beginRound(ev);
    return ev;
  };

  // ===================================================================
  //  ROUND FLOW
  // ===================================================================
  Battle.prototype._beginRound = function (ev) {
    this.round++;
    ev.push({ t: 'round', n: this.round });
    var i, c;
    // 1) Damage / healing over time ticks.
    for (i = 0; i < this.combatants.length && !this.result; i++) {
      c = this.combatants[i];
      if (!c.alive) continue;
      this._tick(c, ev);
    }
    if (this.result) return;
    this._checkPhases(ev);
    if (this.result) return;
    // 2) Everyone alive gains a pip (which may be bright), plus maybe a
    //    Pip Surge pip (v1.2): the event then carries surge: true.
    for (i = 0; i < this.combatants.length; i++) {
      c = this.combatants[i];
      if (!c.alive) continue;
      this._gainPip(c);
      var pe = { t: 'pips', who: c.idx, pips: c.pips, bright: c.bright };
      if (this._surgePip(c)) { pe.pips = c.pips; pe.surge = true; }
      ev.push(pe);
    }
    // 3) Refill the player's hand.
    this._draw(ev);
  };

  Battle.prototype._tick = function (c, ev) {
    var k, eff;
    // DoTs: the amount was SNAPSHOT when the burn was applied (blades,
    // traps, shields, damage bonus, resist and affinity of that instant
    // hit are already baked in). Absorb still soaks ticks.
    for (k = 0; k < c.dots.length; k++) {
      eff = c.dots[k];
      var absorbed = Math.min(c.absorb, eff.amt);
      c.absorb -= absorbed;
      var amt = eff.amt - absorbed;
      c.hp = Math.max(0, c.hp - amt);
      eff.rounds--;
      ev.push({ t: 'tick', target: c.idx, kind: 'dot', amount: amt, absorbed: absorbed, name: eff.name });
      if (c.hp <= 0) { this._kill(c, ev); return; }
    }
    c.dots = c.dots.filter(function (d) { return d.rounds > 0; });
    // HoTs: flat healing, capped at max health.
    for (k = 0; k < c.hots.length; k++) {
      eff = c.hots[k];
      var healed = Math.min(eff.amt, c.maxHp - c.hp);
      c.hp += healed;
      eff.rounds--;
      ev.push({ t: 'tick', target: c.idx, kind: 'hot', amount: healed, name: eff.name });
    }
    c.hots = c.hots.filter(function (h) { return h.rounds > 0; });
  };

  // Refill the hand to handSize; reshuffle the discard pile when the deck runs out.
  Battle.prototype._draw = function (ev) {
    var drawn = [];
    while (this.hand.length < this.handSize) {
      if (this.drawPile.length === 0) {
        if (this.discardPile.length === 0) break;   // nothing left at all; player can still pass
        this.drawPile = this.discardPile;
        this.discardPile = [];
        this._shuffle(this.drawPile);
      }
      var entry = { uid: this._uid++, cardId: this.drawPile.pop() };
      this.hand.push(entry);
      drawn.push(entry);
    }
    if (drawn.length) ev.push({ t: 'draw', cards: drawn });
  };

  Battle.prototype._kill = function (c, ev) {
    c.hp = 0;
    c.alive = false;
    c.dots = []; c.hots = []; c.charms = []; c.wards = []; c.absorb = 0;
    ev.push({ t: 'death', target: c.idx });
    this._checkEnd(ev);
  };

  Battle.prototype._checkEnd = function (ev) {
    if (this.result) return true;
    if (!this.player.alive) { this._end('lose', ev); return true; }
    for (var i = 1; i < this.combatants.length; i++) if (this.combatants[i].alive) return false;
    this._end('win', ev);
    return true;
  };

  Battle.prototype._end = function (result, ev) {
    if (this.result) return;
    this.result = result;
    ev.push({ t: 'end', result: result });
  };

  // ===================================================================
  //  BOSS PHASES  (enemies.js `phases: [{ at, say, cast, once }]`)
  //  When a living enemy's health falls to `at` x maxHp or below, emit
  //  { t:'phase', who, idx, say } and, if `cast` names a card, cast it
  //  for free (no pips, cannot fizzle). Phases fire once (default); with
  //  `once: false` a phase re-arms when the enemy is healed back above it.
  //  Checked at the start of the duel (so `at: 1` = an opening move),
  //  after the player's action, after each enemy action and after the
  //  round's DoT/HoT ticks.
  // ===================================================================
  Battle.prototype._checkPhases = function (ev) {
    for (var i = 1; i < this.combatants.length && !this.result; i++) {
      var c = this.combatants[i];
      if (!c.alive || !c.phases || !c.phases.length) continue;
      for (var k = 0; k < c.phases.length && !this.result && c.alive; k++) {
        var ph = c.phases[k], frac = c.hp / c.maxHp;
        if (c.phaseDone[k]) {
          if (ph.once === false && frac > ph.at) c.phaseDone[k] = false;
          continue;
        }
        if (frac > ph.at) continue;
        c.phaseDone[k] = true;
        ev.push({ t: 'phase', who: c.idx, idx: k, say: ph.say || '' });
        if (ph.cast && this.cards[ph.cast]) this._phaseCast(c, this.cards[ph.cast], ev);
      }
    }
  };

  Battle.prototype._phaseCast = function (c, card, ev) {
    var t = card.type, target = c.idx;
    if (ATTACK_TYPES[t] || t === 'trap' || t === 'weakness') target = 0;
    else if (t === 'heal' || t === 'hot') target = this._lowestAlly(c.idx).idx;
    if (t === 'shield' || t === 'absorb') c.lastDefendRound = this.round;
    this._cast(c.idx, card, target, ev, true);
  };

  // ===================================================================
  //  CASTING (shared by the player, spell scrolls and enemies)
  // ===================================================================

  // Who are the "other side" of this caster?
  Battle.prototype._opponents = function (who) {
    var out = [];
    for (var i = 0; i < this.combatants.length; i++) {
      var c = this.combatants[i];
      if (c.alive && c.isPlayer !== this.combatants[who].isPlayer) out.push(c);
    }
    return out;
  };

  // Pick a valid single target among the caster's opponents.
  Battle.prototype._pickTarget = function (who, targetIdx) {
    var opp = this._opponents(who);
    for (var i = 0; i < opp.length; i++) if (opp[i].idx === targetIdx) return opp[i];
    return opp[0] || null;   // invalid / dead target -> first living opponent
  };

  // Lowest-health-% living member of the caster's own side.
  Battle.prototype._lowestAlly = function (who) {
    var me = this.combatants[who], best = null;
    for (var i = 0; i < this.combatants.length; i++) {
      var c = this.combatants[i];
      if (!c.alive || c.isPlayer !== me.isPlayer) continue;
      if (!best || c.hp / c.maxHp < best.hp / best.maxHp) best = c;
    }
    return best || me;
  };

  // free = true: boss phase cast (no accuracy roll, no pips, no mana).
  Battle.prototype._cast = function (who, card, targetIdx, ev, free) {
    var caster = this.combatants[who];
    var cost = card.pips || 0;

    if (!free) {
      // Accuracy roll. A fizzle wastes the turn but spends no pips or mana.
      var chance = Math.min(100, (card.acc || 100) + caster.acc * 100);
      if (this.rng() * 100 >= chance) {
        ev.push({ t: 'fizzle', who: who, card: card.id });
        return;
      }
      this._payPips(caster, card);
      if (caster.isPlayer) caster.mana = Math.max(0, caster.mana - cost);
    }

    var target, targets;
    switch (card.type) {
      case 'damage':
      case 'dot':
        target = this._pickTarget(who, targetIdx);
        if (!target) return;
        ev.push({ t: 'cast', who: who, card: card.id, targets: [target.idx], free: !!free });
        this._attack(caster, card, [target], ev);
        break;

      case 'aoe':
        targets = this._opponents(who);
        ev.push({ t: 'cast', who: who, card: card.id, targets: targets.map(function (c) { return c.idx; }), free: !!free });
        this._attack(caster, card, targets, ev);
        break;

      case 'heal':
      case 'hot':
        // Player heals self; enemies heal whoever the AI chose (lowest-% ally).
        target = caster;
        if (!caster.isPlayer) {
          var t = this.combatants[targetIdx];
          target = (t && t.alive && !t.isPlayer) ? t : this._lowestAlly(who);
        }
        ev.push({ t: 'cast', who: who, card: card.id, targets: [target.idx], free: !!free });
        this._heal(caster, target, card.value || 0, ev);
        if (card.type === 'hot' && card.hot) {
          var h = { name: card.name, amt: card.hot.amt, rounds: card.hot.rounds, school: card.school };
          target.hots.push(h);
          ev.push({ t: 'hot', target: target.idx, effect: copy(h) });
        }
        break;

      case 'blade':     // + on caster's next matching hit
      case 'shield':    // − on caster's next matching hit taken
        ev.push({ t: 'cast', who: who, card: card.id, targets: [who], free: !!free });
        this._addEffect(caster, card, card.type === 'blade' ? 'charms' : 'wards', ev);
        break;

      case 'trap':      // + on target's next matching hit taken
      case 'weakness':  // − on target's next hit dealt
        target = this._pickTarget(who, targetIdx);
        if (!target) return;
        ev.push({ t: 'cast', who: who, card: card.id, targets: [target.idx], free: !!free });
        this._addEffect(target, card, card.type === 'weakness' ? 'charms' : 'wards', ev);
        break;

      case 'absorb':
        // Absorbs don't add up: a new one replaces a smaller one (stops spam-stacking).
        ev.push({ t: 'cast', who: who, card: card.id, targets: [who], free: !!free });
        caster.absorb = Math.max(caster.absorb, card.value || 0);
        ev.push({ t: 'absorb', target: who, value: caster.absorb });
        break;

      default:
        ev.push({ t: 'cast', who: who, card: card.id, targets: [], free: !!free });
    }
  };

  // ---- v1.2 WS4: spell riders (boss-earned spells, V1.2-CONTRACT §8) ----
  // An attack card may carry `rider`, a second effect that lands after the hit:
  //   rider: { type: 'absorb', value }                       caster soaks `value` (absorb rules: the bigger one stays)
  //   rider: { type: 'hot', hot: { amt, rounds }, name? }     heal-over-time on the CASTER
  //   rider: { type: 'trap', value, affects, name? }          a trap on the struck target (if it still stands)
  // The rider needs the cast to land: a fizzle or a free-cast with no target gives nothing, and a
  // duel that the hit just ended gets no rider. It reuses the normal events ('absorb' / 'hot' /
  // 'ward'), so the duel view needs no changes. Wraps _cast so the core switch stays untouched.
  var castWithoutRider = Battle.prototype._cast;
  Battle.prototype._cast = function (who, card, targetIdx, ev, free) {
    var n = ev.length;
    castWithoutRider.call(this, who, card, targetIdx, ev, free);
    if (!card || !card.rider || this.result) return;
    var cast = null;
    for (var i = n; i < ev.length; i++) if (ev[i].t === 'cast' && ev[i].who === who) { cast = ev[i]; break; }
    if (!cast) return;                                   // fizzled (or no target)
    this._rider(this.combatants[who], card, cast.targets || [], ev);
  };
  Battle.prototype._rider = function (caster, card, targetIdxs, ev) {
    var r = card.rider;
    if (!caster.alive) return;
    if (r.type === 'absorb') {
      caster.absorb = Math.max(caster.absorb, r.value || 0);
      ev.push({ t: 'absorb', target: caster.idx, value: caster.absorb, rider: card.id });
    } else if (r.type === 'hot' && r.hot) {
      var h = { name: r.name || card.name, amt: r.hot.amt, rounds: r.hot.rounds, school: card.school };
      caster.hots.push(h);
      ev.push({ t: 'hot', target: caster.idx, effect: copy(h), rider: card.id });
    } else if (r.type === 'trap') {
      var trap = { id: card.id, name: r.name || card.name, type: 'trap', value: r.value || 0, affects: r.affects || card.school, school: card.school };
      for (var i = 0; i < targetIdxs.length; i++) {
        var t = this.combatants[targetIdxs[i]];
        if (t && t.alive && t !== caster) this._addEffect(t, trap, 'wards', ev);
      }
    }
  };

  // Put a blade/weakness (charms) or trap/shield (wards) on someone.
  Battle.prototype._addEffect = function (onWho, card, listName, ev) {
    var effect = { name: card.name, kind: card.type, value: card.value || 0, affects: card.affects || 'any', school: card.school, sourceCard: card.id };
    var list = onWho[listName];
    var evType = listName === 'charms' ? 'charm' : 'ward';
    if (list.length >= this.maxCharms) {
      // Full (6 max): the spell goes off but has no room to stick.
      ev.push({ t: evType, target: onWho.idx, effect: copy(effect), blocked: true });
      return;
    }
    list.push(effect);
    ev.push({ t: evType, target: onWho.idx, effect: copy(effect) });
  };

  Battle.prototype._heal = function (caster, target, value, ev) {
    var amount = Math.min(value, target.maxHp - target.hp);
    target.hp += amount;
    ev.push({ t: 'heal', who: caster.idx, target: target.idx, amount: amount });
  };

  // ---------------- the damage pipeline ----------------
  // Which of the caster's charms apply? (blades +, weaknesses −)
  // Same name: only the first counts. Doesn't consume anything.
  Battle.prototype._casterMods = function (caster, card) {
    var mult = 1 + caster.dmg, mods = [], used = [], seen = {};
    if (caster.dmg) {
      var pct = Math.round(caster.dmg * 100);
      mods.push({ label: (caster.isPlayer ? 'Your damage ' : caster.name + ' damage ') + pctText(pct), pct: pct, source: 'stat' });
    }
    for (var i = 0; i < caster.charms.length; i++) {
      var c = caster.charms[i];
      if (!matches(c, card) || seen[c.name]) continue;
      seen[c.name] = true;
      var p = c.kind === 'weakness' ? -c.value : c.value;
      mult *= 1 + p / 100;
      used.push(c);
      mods.push({ label: c.name + ' ' + pctText(p), pct: p, source: c.kind });
    }
    return { mult: mult, mods: mods, used: used };
  };

  // Which of the target's wards apply? (traps +, shields −) plus resist
  // and the target's school affinity.
  Battle.prototype._targetMods = function (target, card) {
    var mult = 1, mods = [], used = [], seen = {};
    for (var i = 0; i < target.wards.length; i++) {
      var w = target.wards[i];
      if (!matches(w, card) || seen[w.name]) continue;
      seen[w.name] = true;
      var p = w.kind === 'shield' ? -w.value : w.value;
      mult *= 1 + p / 100;
      used.push(w);
      mods.push({ label: w.name + ' ' + pctText(p) + (w.kind === 'trap' ? ' (on target)' : ''), pct: p, source: w.kind });
    }
    if (target.resist) {
      var r = Math.round(target.resist * 100);
      mult *= Math.max(0, 1 - target.resist);
      mods.push({ label: 'Target resist ' + pctText(-r), pct: -r, source: 'resist' });
    }
    var aff = target.affinity && target.affinity[card.school];
    if (aff) {
      var ap = Math.round(aff * 100);
      mult *= Math.max(0, 1 - aff);
      mods.push({
        label: (aff > 0 ? 'Resists ' : 'Weak to ') + schoolName(card.school) + ' ' + pctText(-ap),
        pct: -ap, source: 'affinity'
      });
    }
    return { mult: mult, mods: mods, used: used };
  };

  function removeUsed(list, used) {
    return list.filter(function (x) { return used.indexOf(x) < 0; });
  }

  // Damage / AoE / DoT. Caster charms are consumed ONCE (even for AoE);
  // each target's wards are consumed separately. A DoT's per-round tick is
  // snapshot with the same multiplier as its instant hit on that target.
  Battle.prototype._attack = function (caster, card, targets, ev) {
    var cm = this._casterMods(caster, card);
    if (cm.used.length) {
      caster.charms = removeUsed(caster.charms, cm.used);
      ev.push({ t: 'consume', target: caster.idx, names: cm.used.map(function (x) { return x.name; }) });
    }
    var totalDealt = 0;
    for (var i = 0; i < targets.length && !this.result; i++) {
      var tgt = targets[i];
      if (!tgt.alive) continue;
      var tm = this._targetMods(tgt, card);
      if (tm.used.length) {
        tgt.wards = removeUsed(tgt.wards, tm.used);
        ev.push({ t: 'consume', target: tgt.idx, names: tm.used.map(function (x) { return x.name; }) });
      }
      var base = this._randInt(card.min || 0, card.max || 0);
      var raw = Math.round(base * cm.mult * tm.mult);
      var absorbed = Math.min(tgt.absorb, raw);
      tgt.absorb -= absorbed;
      var amount = raw - absorbed;
      tgt.hp = Math.max(0, tgt.hp - amount);
      totalDealt += amount;
      ev.push({ t: 'damage', who: caster.idx, target: tgt.idx, amount: amount, absorbed: absorbed, mods: cm.mods.concat(tm.mods), card: card.id });

      if (tgt.hp <= 0) {
        this._kill(tgt, ev);
      } else if (card.type === 'dot' && card.dot) {
        var d = {
          name: card.name, amt: Math.max(0, Math.round(card.dot.amt * cm.mult * tm.mult)),
          base: card.dot.amt, rounds: card.dot.rounds, school: card.school, who: caster.idx
        };
        tgt.dots.push(d);
        ev.push({ t: 'dot', target: tgt.idx, effect: copy(d) });
      }
    }
    // Drain: the caster heals a share of the damage dealt (even on a killing blow).
    if (card.drain && totalDealt > 0 && caster.alive) {
      this._heal(caster, caster, Math.round(totalDealt * card.drain), ev);
    }
  };

  // Shared preview for the player AND the AI (nothing is consumed).
  Battle.prototype._preview = function (who, cardId, targetIdx) {
    var card = this.cards[cardId];
    var caster = this.combatants[who];
    if (!card || !caster) return { min: 0, max: 0, heal: 0, acc: 0, mods: [] };
    var out = {
      min: 0, max: 0, heal: 0,
      acc: Math.min(100, (card.acc || 100) + caster.acc * 100),
      mods: []
    };
    if (ATTACK_TYPES[card.type]) {
      var tgt = this._pickTarget(who, targetIdx);
      var cm = this._casterMods(caster, card);
      var tm = tgt ? this._targetMods(tgt, card) : { mult: 1, mods: [] };
      var mult = cm.mult * tm.mult;
      out.min = Math.round((card.min || 0) * mult);
      out.max = Math.round((card.max || 0) * mult);
      out.mods = cm.mods.concat(tm.mods);
      out.target = tgt ? tgt.idx : null;
      out.absorb = tgt ? tgt.absorb : 0;   // this much will be soaked first
      if (card.type === 'dot' && card.dot) out.dot = { amt: Math.max(0, Math.round(card.dot.amt * mult)), rounds: card.dot.rounds, base: card.dot.amt };
      if (card.drain) out.drain = card.drain;
    } else if (card.type === 'heal' || card.type === 'hot') {
      out.heal = card.value || 0;
      if (card.type === 'hot' && card.hot) out.hot = { amt: card.hot.amt, rounds: card.hot.rounds };
    }
    return out;
  };

  // ---- v1.2 WS4: previews (hand tooltips, the player AI) also report a spell's rider (see _rider) ----
  var previewWithoutRider = Battle.prototype._preview;
  Battle.prototype._preview = function (who, cardId, targetIdx) {
    var out = previewWithoutRider.call(this, who, cardId, targetIdx), card = this.cards[cardId];
    if (card && card.rider) out.rider = copy(card.rider);
    return out;
  };

  // ===================================================================
  //  ENEMY AI  (utility scoring + personality weights)
  //  Affordability always goes through _affordable/_pipValue so bright
  //  pips are understood (a bright pip pays 2 for the enemy's own Hollow
  //  spells).
  // ===================================================================
  Battle.prototype._enemyAct = function (idx, ev) {
    var choice = this._chooseEnemyAction(idx);
    var e = this.combatants[idx];
    if (!choice) {
      e.idleStreak++;
      ev.push({ t: 'pass', who: idx });
      return;
    }
    e.idleStreak = 0;
    var card = this.cards[choice.cardId];
    if (card.type === 'heal' || card.type === 'hot') e.healsCast++;
    if (card.type === 'shield' || card.type === 'absorb') e.lastDefendRound = this.round;
    this._cast(idx, card, choice.target, ev);
  };

  // How hard can the player hit this enemy soon? (used to value shields/weakness)
  Battle.prototype._playerHitEstimate = function (e) {
    var p = this.player, best = 0, any = 0;
    for (var id in this.deckCounts) {
      var c = this.cards[id];
      if (!ATTACK_TYPES[c.type]) continue;
      var aff = (e.affinity && e.affinity[c.school]) || 0;
      var v = avg(c) * (1 + p.dmg) * (1 - e.resist) * (1 - aff);
      if (v > any) any = v;
      if ((c.pips || 0) <= this._pipValue(p, c) + 1 && v > best) best = v;
    }
    return best || any || 100;
  };

  // Best attack this enemy could cast soon (within `extraPips`) that a
  // charm with these `affects` would boost.
  Battle.prototype._bestOwnAttack = function (e, affects, extraPips) {
    var best = 0;
    for (var i = 0; i < e.deck.length; i++) {
      var c = this.cards[e.deck[i]];
      if (!c || !ATTACK_TYPES[c.type]) continue;
      if ((c.pips || 0) > this._pipValue(e, c) + extraPips) continue;
      if (affects !== 'any' && affects !== c.school) continue;
      var v = avg(c) * (1 + e.dmg) * (1 - this.player.resist);
      if (v > best) best = v;
    }
    return best;
  };

  function hasName(list, name) {
    for (var i = 0; i < list.length; i++) if (list[i].name === name) return true;
    return false;
  }

  // Score one card for one enemy. Returns { score, target, why }.
  Battle.prototype._scoreCard = function (e, card, prof) {
    var p = this.player;
    var t = card.type, pv, exp, score;
    if (ATTACK_TYPES[t]) {
      pv = this._preview(e.idx, card.id, 0);
      var hit = pv.acc / 100;
      exp = (pv.min + pv.max) / 2 * hit;
      if (t === 'dot' && pv.dot) exp += pv.dot.amt * pv.dot.rounds * 0.7 * hit;
      if (card.drain) exp += Math.min(card.drain * exp, e.maxHp - e.hp) * 0.5;
      score = exp * prof.attack;
      if (pv.min >= p.hp + p.absorb) score *= prof.finisher;   // sure kill: go for it
      return { score: score, target: 0, why: 'attack' };
    }
    var ph = this._playerHitEstimate(e);
    switch (t) {
      case 'blade':
        if (hasName(e.charms, card.name) || e.charms.length >= this.maxCharms) return { score: 0, why: 'already bladed' };
        return { score: card.value / 100 * this._bestOwnAttack(e, card.affects, 2) * 0.8 * prof.setup, target: e.idx, why: 'blade' };
      case 'trap':
        if (hasName(p.wards, card.name) || p.wards.length >= this.maxCharms) return { score: 0, why: 'already trapped' };
        return { score: card.value / 100 * this._bestOwnAttack(e, card.affects, 2) * 0.8 * prof.setup, target: 0, why: 'trap' };
      case 'weakness':
        if (hasName(p.charms, card.name) || p.charms.length >= this.maxCharms) return { score: 0, why: 'already weakened' };
        return { score: card.value / 100 * ph * prof.debuff, target: 0, why: 'weakness' };
      case 'shield':
        if (this.round - e.lastDefendRound <= prof.defendCooldown) return { score: 0, why: 'defend cooldown' };
        if (hasName(e.wards, card.name) || e.wards.length >= this.maxCharms) return { score: 0, why: 'already shielded' };
        return { score: card.value / 100 * ph * prof.defend, target: e.idx, why: 'shield' };
      case 'absorb':
        if (this.round - e.lastDefendRound <= prof.defendCooldown) return { score: 0, why: 'defend cooldown' };
        if (e.absorb > 0) return { score: 0, why: 'already absorbing' };
        return { score: Math.min(card.value || 0, ph) * 0.7 * prof.defend, target: e.idx, why: 'absorb' };
      case 'heal':
      case 'hot':
        // Heal only when it matters: the weakest ally must be under healAt,
        // and only a limited number of times per duel.
        if (e.healsCast >= prof.maxHeals) return { score: 0, why: 'out of heals' };
        var ally = this._lowestAlly(e.idx);
        var pct = ally.hp / ally.maxHp;
        if (pct >= prof.healAt) return { score: 0, why: 'nobody hurt enough' };
        var amt = card.value || 0;
        if (t === 'hot' && card.hot) amt += card.hot.amt * card.hot.rounds * 0.6;
        return { score: Math.min(amt, ally.maxHp - ally.hp) * (1 + (prof.healAt - pct)) * prof.heal, target: ally.idx, why: 'heal ' + ally.name };
    }
    return { score: 0, why: 'unknown type' };
  };

  // Decide what enemy `idx` does this turn. Returns { cardId, target } or null (pass).
  Battle.prototype._chooseEnemyAction = function (idx) {
    var e = this.combatants[idx];
    var prof = this.aiProfiles[e.ai] || this.aiProfiles.basic;
    var counts = {}, i, id, card;
    for (i = 0; i < e.deck.length; i++) counts[e.deck[i]] = (counts[e.deck[i]] || 0) + 1;

    // 1) Score everything affordable (bright pips included).
    var options = [];
    for (id in counts) {
      card = this.cards[id];
      if (!card || !this._affordable(e, card)) continue;
      var s = this._scoreCard(e, card, prof);
      if (s.score > 0) options.push({ cardId: id, card: card, target: s.target, score: s.score, count: counts[id], why: s.why });
    }

    // Biggest attack in the deck that fits under the pip cap (the "big spell").
    var big = null;
    for (id in counts) {
      card = this.cards[id];
      if (!card || !ATTACK_TYPES[card.type] || (card.pips || 0) > this.maxPips) continue;
      if (!big || card.pips > big.pips || (card.pips === big.pips && avg(card) > avg(big))) big = card;
    }
    var p = this.player;
    var lethal = options.filter(function (o) { return ATTACK_TYPES[o.card.type] && this._preview(idx, o.cardId, 0).min >= p.hp + p.absorb; }, this);
    var mode = 'normal';

    if (lethal.length) {
      // Anyone will take a guaranteed kill.
      options = lethal; mode = 'finish';
    } else if (prof.savesPips && big) {
      // ---- BOSS: save pips for the big spell, buffing while waiting ----
      var isSetup = function (o) { return o.card.type === 'blade' || o.card.type === 'trap' || o.card.type === 'weakness'; };
      if (this._affordable(e, big)) {
        // Can afford it: place free buffs first, then unleash.
        var freeBuffs = options.filter(function (o) { return isSetup(o) && (o.card.pips || 0) === 0; });
        options = freeBuffs.length ? freeBuffs : options.filter(function (o) { return o.cardId === big.id; });
        mode = freeBuffs.length ? 'buff-before-big' : 'unleash';
      } else {
        // Still charging: only free (0-pip) spells, or an urgent heal.
        var allowed = options.filter(function (o) {
          return (o.card.pips || 0) === 0 || o.card.type === 'heal' || o.card.type === 'hot';
        });
        if (allowed.length) { options = allowed; mode = 'charging'; }
        else if (e.idleStreak < prof.maxIdle) { options = []; mode = 'charging-wait'; }
        else mode = 'impatient';   // waited long enough: use whatever it can
      }
    } else {
      // ---- everyone else: maybe skip a turn to afford a much bigger hit ----
      var bestNext = 0;
      if (e.pips + 1 <= this.maxPips) {
        for (id in counts) {
          card = this.cards[id];
          if (card && ATTACK_TYPES[card.type] && card.pips === this._pipValue(e, card) + 1) {
            var pv = this._preview(idx, id, 0);
            bestNext = Math.max(bestNext, (pv.min + pv.max) / 2 * pv.acc / 100 * prof.attack);
          }
        }
      }
      // Waiting a round for `bestNext` is worth about half of it per round.
      if (bestNext > 0 && prof.saveBias > 0) {
        options.push({ cardId: null, card: null, target: null, score: bestNext / 2 * prof.saveBias, count: 1, why: 'save pips' });
      }
    }

    // 2) Weighted random pick, strongly favouring the best options.
    var top = 0;
    for (i = 0; i < options.length; i++) top = Math.max(top, options[i].score);
    var pool = options.filter(function (o) { return top > 0 && o.score / top >= prof.minRel; });
    var total = 0;
    pool.forEach(function (o) { o.weight = o.count * Math.pow(o.score / top, prof.sharpness); total += o.weight; });
    var pick = null;
    if (pool.length) {
      var r = this.rng() * total;
      for (i = 0; i < pool.length; i++) { r -= pool[i].weight; if (r <= 0) { pick = pool[i]; break; } }
      if (!pick) pick = pool[pool.length - 1];
    }

    // 3) Debug log (keep the last 200 decisions).
    this.aiLog.push({
      round: this.round, who: idx, name: e.name, ai: e.ai, pips: e.pips, bright: e.bright, mode: mode,
      choice: pick ? (pick.cardId || 'pass(save)') : 'pass',
      options: pool.map(function (o) { return { card: o.cardId || 'pass', score: Math.round(o.score), why: o.why }; })
    });
    if (this.aiLog.length > 200) this.aiLog.shift();

    if (!pick || !pick.cardId) return null;
    return { cardId: pick.cardId, target: pick.target };
  };

  // ---------------- randomness (uses the injectable rng) ----------------
  Battle.prototype._randInt = function (min, max) {
    if (max <= min) return min;
    return min + Math.floor(this.rng() * (max - min + 1));
  };
  Battle.prototype._shuffle = function (arr) {
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(this.rng() * (i + 1));
      var tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
    }
    return arr;
  };

  WF.Battle = Battle;
  if (typeof module !== 'undefined' && module.exports) module.exports = Battle;
})(typeof window !== 'undefined' ? window : global);
