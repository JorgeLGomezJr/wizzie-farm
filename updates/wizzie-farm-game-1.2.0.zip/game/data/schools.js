// =====================================================================
//  WIZZIE FARM — SCHOOLS
//  Three playable schools + the universal "Lumen" (good) school and the
//  enemy "Hollow" (evil) school.
//
//  Stats per school:
//    baseHP / hpPerLevel     -> max health
//    baseMana / manaPerLevel -> max mana (each pip costs 1 mana to cast)
//    dmg    -> outgoing damage bonus   (0.15 = +15%)
//    resist -> incoming damage reduction (0.10 = -10%)
//    acc    -> accuracy bonus added to every card (0.05 = +5%)
// =====================================================================
window.WF = window.WF || { data: {} };

WF.data.schools = {
  stoneward: {
    id: 'stoneward', name: 'Stoneward', role: 'Tank', playable: true,
    color: '#d4a25f', dark: '#6b4a22', glyph: '◆',
    tagline: 'Unbreakable earth magic. Outlast anything.',
    desc: 'Stoneward wizards draw power from the mountains. Highest health and resistance, damage shields that soak hits, and steady accurate spells. Slower to kill, almost impossible to kill.',
    baseHP: 580, hpPerLevel: 54, baseMana: 20, manaPerLevel: 2,
    dmg: -0.10, resist: 0.10, acc: 0.05,
    bars: { health: 5, damage: 2, defense: 5, accuracy: 4 },
    robe: '#8a6a3b', hat: '#5c4320', trim: '#f0c27a'
  },
  tidecaller: {
    id: 'tidecaller', name: 'Tidecaller', role: 'Balanced', playable: true,
    color: '#4fc3e8', dark: '#1d5a73', glyph: '≈',
    tagline: 'The tide gives and takes. Heal, drain, endure.',
    desc: 'Tidecaller wizards command the moon and the sea. Solid health, the best healing in the game, and draining spells that hurt enemies while restoring you. Good at everything.',
    baseHP: 510, hpPerLevel: 46, baseMana: 24, manaPerLevel: 2,
    dmg: 0.0, resist: 0.05, acc: 0.0,
    bars: { health: 4, damage: 3, defense: 3, accuracy: 3 },
    robe: '#2a6f9a', hat: '#174a68', trim: '#bdefff'
  },
  emberstrike: {
    id: 'emberstrike', name: 'Emberstrike', role: 'Damage', playable: true,
    color: '#ff6b3d', dark: '#7a2410', glyph: '✹',
    tagline: 'Fire and lightning. End fights fast.',
    desc: 'Emberstrike wizards channel wildfire and storm. The biggest hits, burning damage-over-time and area spells - but the lowest health and accuracy. Kill them before they kill you.',
    baseHP: 450, hpPerLevel: 42, baseMana: 22, manaPerLevel: 2,
    dmg: 0.35, resist: 0.0, acc: 0.0,
    bars: { health: 2, damage: 5, defense: 1, accuracy: 2 },
    robe: '#a8321b', hat: '#6e1c0c', trim: '#ffcf6a'
  },
  // Universal "good" magic of the Lumen Order (earned through quests).
  lumen: {
    id: 'lumen', name: 'Lumen', role: 'Universal', playable: false,
    color: '#ffd76a', dark: '#7a5f14', glyph: '☀'
  },
  // Enemy magic of the Hollow Court (the force of evil).
  hollow: {
    id: 'hollow', name: 'Hollow', role: 'Evil', playable: false,
    color: '#a879ff', dark: '#3a1d6e', glyph: '☽'
  }
};

// Order shown on the school-select screen.
WF.data.playableSchools = ['stoneward', 'tidecaller', 'emberstrike'];
