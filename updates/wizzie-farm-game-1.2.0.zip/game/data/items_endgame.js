// =====================================================================
//  WIZZIE FARM — ENDGAME GEAR (v1.2 "Deck & Dungeon", workstream WS2)
//
//  Contract: docs/V1.2-CONTRACT.md §2.1-2.3, §2.5 (looks), §6.1 (school-
//  specific gear, random-school drops), §6.3 (tiers T1/T2/T3, upgrades,
//  salvage, set bonuses), §6.4 (gear-vs-level rule).
//  Design + the stat budget tables: docs/design/combat-and-progression.md §16.
//  Proof: node tests/balance-sim.js --only=endgame (part of --check).
//  Loaded right after items.js (it adds to WF.data.items).
//
//  THE LEVEL 10 POWER SPIKE (a W101-style ladder):
//    * STARBOUND (legendary): hat, robe, wand, amulet. Hollow Orrery bosses
//      (WS4 wires the drops): Sentinel -> amulet, Warden Morrow -> wand,
//      Starless Archon -> hat + robe.
//    * STARWALKER GREAVES (legendary): the best boots, from the Nyx re-fight
//      (enemies.js nyx_herald). They count toward the Starbound set bonus.
//    * ARTIFICER (epic, crafted: true): all five slots, ONLY from Tamsin
//      Gearwright in Lanternmere (recipes.js). 90-97 % of the same-tier
//      Starbound budget with a different mix (more Pip Surge, less Power Pip).
//    Every piece exists for every school (role-shaped stats: Stoneward =
//    health/resist, Tidecaller = mana/accuracy, Emberstrike = damage/Power Pip)
//    and in three tiers:
//      T1 <base>        Starbound / Starwalker / Artificer's        (drop / craft)
//      T2 <base>_t2     Radiant Starbound ... / Master Artificer's  (rare drop or upgrade)
//      T3 <base>_t3     Ascendant Starbound ... / Grand Artificer's (upgrade only)
//    School versions are <id>_<school>; the school-less <id> is the DROP id
//    with `variants` (a drop rolls the school 1/3 each, state.js rollGear).
//    `next` = the id the piece upgrades into at Tamsin (WF.data.gearUpgrades).
//
//  New gear stats (percent, like dmg): brightPip ("Power Pip": chance each
//  new pip is bright) and pipSurge ("Pip Surge": chance to gain 2 pips in a
//  round). Caps in progression.js (brightPipCap 0.60, pipSurgeCap 0.35).
//
//  HOW THE NUMBERS ARE MADE: the tables below hold the T3 stats of each
//  school version (hand-tuned with tests/balance-sim.js). T1 and T2 are
//  T3 x TIER_SCALE (rounded; a stat never rounds away to 0). The school-less
//  base piece takes the lowest value of each stat across the three schools
//  (so every school version is at least as good as its base).
// =====================================================================
window.WF = window.WF || { data: {} };

(function () {
  var I = WF.data.items;
  var gen = WF.data.gearGen;
  var SCHOOLS = ['stoneward', 'tidecaller', 'emberstrike'];
  var STATS = ['hp', 'mana', 'dmg', 'resist', 'acc', 'brightPip', 'pipSurge'];

  // ---------------------------------------------------------------- tiers
  // Share of the T3 stats a lower tier keeps: `off` for the offensive stats
  // (damage, Power Pip, Pip Surge), `def` for the rest (health, resist,
  // accuracy, mana). The set bonuses count ANY tier, so a T1 set already
  // gets them: that is why the offensive share of T1 is the lower one.
  // Tuned with tests/balance-sim.js so a full Starbound+Starwalker set (with
  // its set bonuses) gives, vs typical L10 gear (contract §6.3):
  //   T1 ~ +15-20 % damage output / +12 % max health
  //   T2 ~ +25-30 % / +20 %
  //   T3 ~ +35-45 % / +30 %
  // ARTIFICER lower tiers stay inside the contract's 90-97 % band of the
  // same-tier Starbound piece (keepShare below trims or pads health only
  // when rounding pushed a piece out of it).
  var TIER_SCALE = {
    1: { off: 0.61, def: 0.75 },
    2: { off: 0.78, def: 0.86 },
    3: { off: 1, def: 1 }
  };
  var OFF = { dmg: 1, brightPip: 1, pipSurge: 1 };
  // Sell price multiplier per tier (on top of the normal L10 rarity price).
  var TIER_SELL = { 1: 1, 2: 1.5, 3: 2 };
  WF.data.gearTiers = {
    1: { name: 'Tier 1', short: 'T1' },
    2: { name: 'Tier 2', short: 'T2' },
    3: { name: 'Tier 3', short: 'T3' },
    scale: TIER_SCALE
  };

  // ---------------------------------------------------------------- set bonuses (§6.3)
  // Count = equipped pieces of the set (any tier) that the wearer's school
  // can wear. maxCount 4 for Starbound implements "Starwalker counts as
  // Starbound only if you wear <= 3 other Starbound pieces": the four
  // Starbound pieces + Starwalker can never count as more than 4.
  // `school` adds extra stats for one school (`schoolText` = its label then).
  WF.data.gearSets = {
    starbound: {
      name: 'Starbound', maxCount: 4,
      bonuses: [
        { count: 2, stats: { brightPip: 3 }, text: '+3% Power Pip' },
        { count: 4, stats: { dmg: 5 }, school: { stoneward: { resist: 4 } }, text: '+5% Damage', schoolText: { stoneward: '+5% Damage, +4% Resist' } }
      ]
    },
    artificer: {
      name: 'Artificer', maxCount: 5,
      bonuses: [
        { count: 2, stats: { pipSurge: 3 }, text: '+3% Pip Surge' },
        { count: 4, stats: { hp: 60, acc: 2 }, text: '+60 Health, +2% Accuracy' },
        { count: 5, stats: { pipSurge: 2 }, text: '+2% Pip Surge' }
      ]
    }
  };

  // ---------------------------------------------------------------- upgrades + salvage (§6.3)
  // Tamsin (npc) upgrades a piece one tier: T1 -> T2 (`t2`), T2 -> T3 (`t3`),
  // same school and slot; the old piece is consumed. Salvage turns an
  // unwanted endgame piece into Starlight Essence (t1 / t2 / t3 per piece).
  // tests/dungeon-sim.js (WS4) reads WF.data.gearUpgrades.starbound.
  // Farming math: docs/design/combat-and-progression.md §16.8.
  WF.data.gearUpgrades = {
    npc: 'tamsin',
    starbound:  { t2: { star_shard: 220, gold: 2500 }, t3: { archon_core: 3, starlight_essence: 10, gold: 5000 }, salvage: { t1: 1, t2: 3, t3: 6 } },
    starwalker: { t2: { star_shard: 220, gold: 2500 }, t3: { archon_core: 1, starlight_essence: 15, gold: 5000 }, salvage: { t1: 1, t2: 3, t3: 6 } },
    artificer:  { t2: { star_shard: 220, gold: 2500 }, t3: { archon_core: 3, starlight_essence: 10, gold: 5000 }, salvage: { t1: 1, t2: 3, t3: 6 } }
  };

  // ---------------------------------------------------------------- reagents
  var REAGENTS = {
    star_shard:   { type: 'reagent', name: 'Star Shard',   color: '#cfe0ff', sell: 12,
                    desc: 'A sliver of a star that fell into the Hollow Orrery. Every creature down there carries a few. Tamsin wants all of them.' },
    archon_core:  { type: 'reagent', name: 'Archon Core',  color: '#7a4ad8', sell: 45,
                    desc: 'The still-turning heart of the Starless Archon. Warm, heavy, and humming in a key nobody has named yet.' },
    starlight_essence: { type: 'reagent', name: 'Starlight Essence', color: '#fff3c4', sell: 20,
                    desc: "What is left when Tamsin takes a piece of star-gear apart: one bright drop of the sky. Ascendant gear can't be made without it." }
  };

  // ---------------------------------------------------------------- the sets
  // Per slot: base id, noun, style, look per school (+ 'base'), T3 stats per
  // school, flavour text per school (+ 'base').
  // look rows: [color, color2, gem, fx]
  var SB_LOOK = { base: ['#141a3a', '#ffe9a0', '#bfe6ff', 'sparkle'], stoneward: ['#2a2238', '#e8c070', '#ffcf6a', 'sparkle'],
                  tidecaller: ['#0e1e44', '#cfe8ff', '#7fe0ff', 'frost'], emberstrike: ['#2a0e24', '#ffcf6a', '#ff8a4a', 'embers'] };
  var SW_LOOK = { base: ['#1a1030', '#e8e0ff', '#b06cff', 'shadow'], stoneward: ['#2a2238', '#e8c070', '#ffcf6a', 'shadow'],
                  tidecaller: ['#0e1e44', '#cfe8ff', '#7fe0ff', 'frost'], emberstrike: ['#2a0e24', '#ffcf6a', '#ff8a4a', 'embers'] };
  var AF_LOOK = { base: ['#6a4a2e', '#d8a84a', '#7fe0ff', 'glow'], stoneward: ['#5a4a3a', '#c9a24a', '#d4a25f', 'glow'],
                  tidecaller: ['#3a4a5a', '#d8b860', '#4fc3e8', 'frost'], emberstrike: ['#5a2a1a', '#e0a040', '#ff6b3d', 'embers'] };
  var AF_BRASS = { base: ['#b08a3a', '#6a4a2e', '#7fe0ff', 'glow'], stoneward: ['#8a7a5a', '#5a4a3a', '#d4a25f', 'glow'],
                   tidecaller: ['#a8b8c8', '#3a4a5a', '#4fc3e8', 'frost'], emberstrike: ['#c08a3a', '#5a2a1a', '#ff6b3d', 'embers'] };
  var SB_WORD = { stoneward: 'Bastion', tidecaller: 'Moontide', emberstrike: 'Flare' };
  var AF_WORD = { stoneward: 'Ironbound', tidecaller: 'Tidegauge', emberstrike: 'Furnace' };

  var SETS = [
    { set: 'starbound', cost: 'starbound', rarity: 'legendary', unique: true, words: SB_WORD,
      prefix: { 1: 'Starbound', 2: 'Radiant Starbound', 3: 'Ascendant Starbound' },
      tierFlavor: { 2: 'Tamsin threaded it with starlight; the trim glows now.', 3: 'Ascended: it carries a little piece of the sky wherever you go.' },
      pieces: [
        { slot: 'hat', id: 'starbound_hat', noun: 'Circlet', style: 'starbound', looks: SB_LOOK,
          t3: { stoneward:  { hp: 235, dmg: 10, resist: 2, mana: 6, brightPip: 5, pipSurge: 1 },
                tidecaller: { hp: 220, dmg: 10, acc: 7, mana: 10, brightPip: 5, pipSurge: 1 },
                emberstrike:{ hp: 200, dmg: 12, acc: 5, mana: 6, brightPip: 5, pipSurge: 1 } },
          desc: { base: 'A halo of seven tiny stars that circle your hood. They were there when the Orrery was built, and they remember the tune.',
                  stoneward: 'Its stars move slowly and never stray. Stone likes stars like that.',
                  tidecaller: 'The stars rise and fall around your head like a tide that forgot which way is down.',
                  emberstrike: 'Seven little suns, all of them showing off.' } },
        { slot: 'robe', id: 'starbound_robe', noun: 'Mantle', style: 'starbound', looks: SB_LOOK,
          t3: { stoneward:  { hp: 370, resist: 11, dmg: 5, mana: 7, brightPip: 4, pipSurge: 1 },
                tidecaller: { hp: 345, resist: 14, dmg: 5, mana: 11, brightPip: 4, pipSurge: 1 },
                emberstrike:{ hp: 335, resist: 12, dmg: 7, acc: 2, mana: 8, brightPip: 4, pipSurge: 1 } },
          desc: { base: 'A mantle cut from the night sky over the Orrery. Its shoulder plates float a finger-width from the cloth and hum when you cast.',
                  stoneward: 'Heavy as a mountain at night and twice as patient.',
                  tidecaller: 'Starlight pools in its folds like water. It never quite spills.',
                  emberstrike: 'Every star on it is a tiny ember that refuses to go out.' } },
        { slot: 'wand', id: 'starbound_wand', noun: 'Staff', style: 'starbound', looks: SB_LOOK,
          t3: { stoneward:  { dmg: 20, acc: 8, hp: 70, resist: 1, mana: 6, brightPip: 5 },
                tidecaller: { dmg: 19, acc: 10, hp: 60, mana: 9, brightPip: 5 },
                emberstrike:{ dmg: 21, acc: 8, hp: 50, mana: 6, brightPip: 5 } },
          desc: { base: 'A staff crowned with a working orrery the size of an apple. The planets line up just before your biggest spells.',
                  stoneward: 'Its little planets are carved from river stones. They orbit very, very steadily.',
                  tidecaller: 'The orrery on top has a moon that pulls at your mana like a tide.',
                  emberstrike: 'Every planet on this orrery is on fire. That is not how orreries work. Nobody has told it.' } },
        { slot: 'amulet', id: 'starbound_amulet', noun: 'Crescent', style: 'starbound',
          looks: { base: ['#1a1e3a', '#ffe9a0', '#ffffff', 'radiant'], stoneward: ['#2a2238', '#e8c070', '#ffcf6a', 'radiant'],
                   tidecaller: ['#0e1e44', '#cfe8ff', '#7fe0ff', 'frost'], emberstrike: ['#2a0e24', '#ffcf6a', '#ff8a4a', 'embers'] },
          t3: { stoneward:  { hp: 250, dmg: 10, resist: 3, acc: 4, mana: 6, brightPip: 5, pipSurge: 1 },
                tidecaller: { hp: 240, dmg: 10, resist: 5, acc: 6, mana: 9, brightPip: 5, pipSurge: 1 },
                emberstrike:{ hp: 225, dmg: 12, resist: 4, acc: 4, mana: 6, brightPip: 6, pipSurge: 1 } },
          desc: { base: 'A silver crescent holding one bright star. The Orrery Sentinel guarded it for a thousand years and never once looked at it.',
                  stoneward: 'The crescent is set in granite. The star in it never flickers.',
                  tidecaller: 'The crescent waxes and wanes with your mana. Full moon: full pips.',
                  emberstrike: 'The star in this crescent is very clearly trying to explode. Politely.' } }
      ] },
    { set: 'starbound', cost: 'starwalker', rarity: 'legendary', unique: true, words: SB_WORD,
      prefix: { 1: 'Starwalker', 2: 'Radiant Starwalker', 3: 'Ascendant Starwalker' },
      tierFlavor: { 2: 'Tamsin re-forged the soles with starlight. The motes they leave stay a little longer.', 3: 'Ascended: every step leaves a small, permanent star.' },
      pieces: [
        { slot: 'boots', id: 'starwalker_boots', noun: 'Greaves', style: 'starwalker', looks: SW_LOOK,
          t3: { stoneward:  { hp: 225, dmg: 8, acc: 9, resist: 3, mana: 7, brightPip: 3, pipSurge: 3 },
                tidecaller: { hp: 210, dmg: 8, acc: 11, resist: 4, mana: 10, brightPip: 3, pipSurge: 3 },
                emberstrike:{ hp: 195, dmg: 8, acc: 9, resist: 3, mana: 7, brightPip: 4, pipSurge: 3 } },
          desc: { base: 'Nyx walked between the stars in these. Now they leave faint star motes wherever you step, and the dark politely gets out of the way.',
                  stoneward: 'Heavy greaves of night-iron. The star motes they leave behind are very slow and very sure.',
                  tidecaller: 'Every step leaves a ripple of starlight, like walking on a calm sea at night.',
                  emberstrike: 'The star motes these leave behind are, regrettably, on fire.' } }
      ] },
    { set: 'artificer', cost: 'artificer', rarity: 'epic', crafted: true, words: AF_WORD,
      prefix: { 1: "Artificer's", 2: "Master Artificer's", 3: "Grand Artificer's" },
      tierFlavor: { 2: 'Master work: Tamsin re-cut every gear by hand and signed the inside.', 3: 'Grand work: the gears turn on their own now. Tamsin cried a little.' },
      pieces: [
        { slot: 'hat', id: 'artificer_hat', noun: 'Cap', style: 'artisan', looks: AF_LOOK,
          t3: { stoneward:  { hp: 255, dmg: 7, resist: 2, mana: 7, brightPip: 2, pipSurge: 4 },
                tidecaller: { hp: 230, dmg: 8, acc: 5, mana: 10, brightPip: 2, pipSurge: 4 },
                emberstrike:{ hp: 200, dmg: 11, acc: 2, mana: 6, brightPip: 2, pipSurge: 4 } },
          desc: { base: "Brass goggles, a leather cap and eleven tiny screwdrivers. Tamsin says the goggles are for 'seeing the pips coming'.",
                  stoneward: 'Riveted plates over thick leather. The goggles have a little wiper for dust.',
                  tidecaller: 'One lens of the goggles is a tide gauge. It is always right about the weather.',
                  emberstrike: 'Smoked-glass goggles for looking straight into a forge. Or a fireball. Mostly a fireball.' } },
        { slot: 'robe', id: 'artificer_robe', noun: 'Workcoat', style: 'artisan', looks: AF_LOOK,
          t3: { stoneward:  { hp: 375, resist: 11, dmg: 2, mana: 6, brightPip: 2, pipSurge: 4 },
                tidecaller: { hp: 340, resist: 14, dmg: 3, mana: 9, brightPip: 2, pipSurge: 4 },
                emberstrike:{ hp: 330, resist: 12, dmg: 6, acc: 1, mana: 5, brightPip: 2, pipSurge: 4 } },
          desc: { base: 'A layered coat with a tool belt, nine pouches and brass buckles. One pouch is just for snacks. Tamsin insisted.',
                  stoneward: 'The pouches are lined with slate. You could fall off the Spire in this and only your pride would bruise.',
                  tidecaller: 'Waxed against spray, with a little brass compass that always points at the nearest friend.',
                  emberstrike: 'Scorch marks on the sleeves are a feature. Tamsin calls them "proof of testing".' } },
        { slot: 'boots', id: 'artificer_boots', noun: 'Boots', style: 'artisan',
          looks: { base: ['#5a3e24', '#d8a84a', '#7fe0ff', 'glow'], stoneward: ['#4a3e2e', '#c9a24a', '#d4a25f', 'glow'],
                   tidecaller: ['#2e3e4a', '#d8b860', '#4fc3e8', 'frost'], emberstrike: ['#4a2418', '#e0a040', '#ff6b3d', 'embers'] },
          t3: { stoneward:  { hp: 255, dmg: 5, acc: 9, resist: 5, mana: 6, brightPip: 1, pipSurge: 5 },
                tidecaller: { hp: 240, dmg: 6, acc: 12, resist: 4, mana: 9, brightPip: 1, pipSurge: 5 },
                emberstrike:{ hp: 200, dmg: 8, acc: 10, resist: 3, mana: 6, brightPip: 2, pipSurge: 5 } },
          desc: { base: 'Buckled work boots with brass toe-caps and springs in the heels. You will walk into the duel circle a little taller.',
                  stoneward: 'Iron toe-caps and hobnails. You can hear a Stoneward artificer coming from three streets away.',
                  tidecaller: 'Cork soles with brass buckles. They float, which Tamsin says is "a safety feature".',
                  emberstrike: 'Heat-proof soles. Tamsin tested them by walking through a bonfire. Twice.' } },
        { slot: 'wand', id: 'artificer_wand', noun: 'Wand', style: 'forged', looks: AF_BRASS,
          t3: { stoneward:  { dmg: 15, acc: 8, hp: 95, resist: 2, mana: 6, brightPip: 2, pipSurge: 4 },
                tidecaller: { dmg: 17, acc: 9, hp: 55, mana: 9, brightPip: 2, pipSurge: 4 },
                emberstrike:{ dmg: 19, acc: 8, hp: 40, mana: 5, brightPip: 2, pipSurge: 4 } },
          desc: { base: 'Brass rings turn around a core of star crystal. Each ring clicks into place as your pips arrive.',
                  stoneward: 'Iron rings, a granite core. It ticks like a very slow, very determined clock.',
                  tidecaller: 'The crystal core is full of seawater. The rings turn with the tide.',
                  emberstrike: 'The rings spin so fast they glow. Hold it by the handle. Only the handle.' } },
        { slot: 'amulet', id: 'artificer_amulet', noun: 'Medallion', style: 'gearwork', looks: AF_BRASS,
          t3: { stoneward:  { hp: 290, dmg: 7, resist: 4, acc: 3, mana: 5, brightPip: 2, pipSurge: 4 },
                tidecaller: { hp: 255, dmg: 8, resist: 5, acc: 6, mana: 8, brightPip: 2, pipSurge: 4 },
                emberstrike:{ hp: 225, dmg: 10, resist: 4, acc: 4, mana: 5, brightPip: 3, pipSurge: 4 } },
          desc: { base: 'A brass medallion with one gear that turns on its own. It speeds up just before a lucky round.',
                  stoneward: 'A heavy iron medallion. Its gear turns once a minute, exactly, forever.',
                  tidecaller: 'The gear inside turns with the moon. Tamsin swears she did not plan that.',
                  emberstrike: 'The gear spins so fast it whistles. It is very pleased with itself.' } }
      ] }
  ];

  function sell(rarity, tier) {
    var b = gen && gen.genSell ? gen.genSell(10, rarity) : (rarity === 'legendary' ? 221 : 143);
    return Math.round(b * (TIER_SELL[tier] || 1));
  }
  function scaled(t3, tier) {
    var out = {}, sc = TIER_SCALE[tier];
    STATS.forEach(function (k) {
      if (!t3[k]) return;
      // health in steps of 5; Power Pip / Pip Surge round down unless within 0.25 of the next point
      var f = OFF[k] ? sc.off : sc.def, x = t3[k] * f;
      var v = k === 'hp' ? Math.round(x / 5) * 5 : (k === 'brightPip' || k === 'pipSurge') ? Math.floor(x + 0.25) : Math.round(x);
      out[k] = Math.max(1, v);
    });
    return out;
  }
  // gear score, same weights as state.js gearScore / tests/data-check.js
  var SCORE_W = { hp: 1 / 8, dmg: 4, resist: 4, acc: 1.5, mana: 2, brightPip: 4, pipSurge: 4 };
  function score(st) { return Object.keys(SCORE_W).reduce(function (n, k) { return n + (st[k] || 0) * SCORE_W[k]; }, 0); }
  // Artificer T1/T2: rounding of small stats (a 2 % Power Pip, a 1 % resist)
  // can push a scaled piece out of the contract's 90-97 % band of the
  // same-tier Starbound budget (boots: 93-103 % of Starwalker). Only then
  // its health is moved (in steps of 5) to just inside the band, never above
  // the health of the tier above. Pieces already inside keep their scaled
  // health, so health still rises T1 -> T2 -> T3.
  var SHARE_BAND = { def: [0.91, 0.96], boots: [0.94, 1.02] };
  function keepShare(af, sbT, slot, cap) {
    var band = SHARE_BAND[slot] || SHARE_BAND.def, r = score(af) / score(sbT);
    if (r >= band[0] && r <= band[1]) return af;
    var want = (r < band[0] ? band[0] : band[1]) * score(sbT), hp = (af.hp || 0) + (want - score(af)) / SCORE_W.hp;
    af.hp = Math.min(cap || Infinity, Math.max(5, (r < band[0] ? Math.ceil(hp / 5) : Math.floor(hp / 5)) * 5));
    return af;
  }
  function minStats(byS) {
    var out = {};
    STATS.forEach(function (k) {
      var v = Math.min.apply(null, SCHOOLS.map(function (s) { return byS[s][k] || 0; }));
      if (v > 0) out[k] = v;
    });
    return out;
  }
  function tierId(id, tier) { return tier === 1 ? id : id + '_t' + tier; }
  function look(row, style, tier) {
    var l = { style: style, color: row[0], color2: row[1], gem: row[2], fx: row[3], tier: tier };
    // T2+ accent colour comes from the set's own palette in the renderer (WS6); no shared accent here          // §6.3: T2+ second accent colour (glowing trim); T3 also gets the set aura (WS6 reads `tier`)
    return l;
  }

  var E = {};
  Object.keys(REAGENTS).forEach(function (id) { E[id] = REAGENTS[id]; });
  // the best-in-slot (Starbound / Starwalker) piece of each slot, for keepShare
  var BIS = {};
  SETS.forEach(function (S) { if (S.set === 'starbound') S.pieces.forEach(function (pc) { BIS[pc.slot] = pc; }); });
  SETS.forEach(function (S) {
    S.pieces.forEach(function (pc) {
      [3, 2, 1].forEach(function (tier) {          // T3 first: a lower tier never gets more health than the tier above
        var byS = {}, bis = S.set !== 'starbound' && tier < 3 && BIS[pc.slot];
        SCHOOLS.forEach(function (s) {
          byS[s] = scaled(pc.t3[s], tier);
          if (bis) keepShare(byS[s], scaled(bis.t3[s], tier), pc.slot, E[tierId(pc.id, tier + 1) + '_' + s].stats.hp);
        });
        var base = tierId(pc.id, tier), next = tier < 3 ? tierId(pc.id, tier + 1) : null;
        function make(id, school) {
          var it = {
            type: 'gear', slot: pc.slot, level: 10, rarity: S.rarity, set: S.set, tier: tier, upgradeCost: S.cost,
            name: S.prefix[tier] + (school ? ' ' + S.words[school] : '') + ' ' + pc.noun,
            stats: school ? byS[school] : minStats(byS),
            look: look(pc.looks[school || 'base'], pc.style, tier),
            desc: pc.desc[school || 'base'] + (S.tierFlavor[tier] ? ' ' + S.tierFlavor[tier] : ''),
            price: 0, sell: sell(S.rarity, tier)
          };
          if (school) it.school = school;
          if (next) it.next = school ? next + '_' + school : next;
          if (S.unique) it.unique = true;
          if (S.crafted) it.crafted = true;
          E[id] = it;
          return it;
        }
        var b = make(base, null);
        b.variants = {};
        SCHOOLS.forEach(function (s) { make(base + '_' + s, s); b.variants[s] = base + '_' + s; });
      });
    });
  });

  // ---------------------------------------------------------------- mount (rare Archon drop; WS4 wires it)
  E.mount_orrery_strider = {
    type: 'mount', name: 'Orrery Strider', rarity: 'legendary', level: 10, speed: 0.60, price: 0, sell: 560,
    mount: { kind: 'strider', coat: '#b08a3a', mane: '#7fe0ff', saddle: '#2a1d4e', trim: '#ffd76a', gem: '#bfe6ff' },
    desc: 'A brass mechanical stag that walked out of the Hollow Orrery after the Archon fell. Its antlers are a tiny working sky.'
  };

  Object.keys(E).forEach(function (id) { E[id].id = id; I[id] = E[id]; });
})();
