WIZZIE FARM  —  v1.2.0 "Deck & Dungeon"
=======================================
A single-player wizard RPG in the spirit of Wizard101. Made for fun.

HOW TO PLAY
-----------
1. Start the game:
     - Desktop app (Windows):  double-click  "Wizzie Farm.exe"  (see docs\DESKTOP-APP.md), or
     - Browser:  double-click  "Play Wizzie Farm.html"  (Chrome or Edge recommended).
2. Create a wizard and choose a school:
     Stoneward   - Tank      (most health, shields, steady damage)
     Tidecaller  - Balanced  (heals, drains, solid at everything)
     Emberstrike - Damage    (huge hits and burns, fragile)
3. Talk to Headmistress Aurelia (gold "!" above her head) to start the story.

UP TO 3 WIZARDS
  Your account holds 3 wizards. "Choose your Wizard" shows them on pedestals in
  their gear: click one (or use the arrow keys) and press Play. Pick an empty
  pedestal to Create a new wizard. Delete asks you to type the wizard's name.
  In the game, Menu > Switch Wizard saves and takes you back to that screen.
  A save from v1.1 is moved into the first slot automatically.

Your progress saves automatically (browser: in the browser's storage; desktop app:
in %APPDATA%\Wizzie Farm\saves with 5 rotating backups). Use Menu > Export this
wizard / Export all wizards to keep a backup file; import it on the wizard screen
(Import on an empty pedestal) or with Menu > Import save file.

DESKTOP APP UPDATES
  The desktop app updates itself: when a new version is ready you see
  "Update ready - restart". Menu > Check for updates checks right away.
  Online updates are switched on once a GitHub repository is set
  (docs\DESKTOP-APP.md). F11 = fullscreen.

CONTROLS
--------
  W / S ........ walk forward / back        A / D .... turn
  Q / Z ........ strafe left / right        Shift .... run
  Mouse drag ... rotate camera              Wheel .... zoom
  E ............ talk to the nearest NPC (or click them) / relight lanterns
  L Quest log    K Spellbook & deck    B Backpack    Esc Menu
  H / J ........ drink a health / mana potion
  R ............ ride / dismount your mount (buy one from Hollis Brightmane
                 at the Brightmane Stables in Lanternmere)

DUELS
  Walk into a monster to start a duel. Each round you gain a pip.
  Click a spell card to cast it (or press 1-7). Right-click a card to discard it.
  Blades boost your next attack, traps make the target take more damage,
  shields reduce the next hit you take. Hover a card to see exactly how
  your blades and the enemy's traps/shields will change its damage.
  Spells cost pips AND mana. Restore mana with potions, wisps (glowing orbs
  in the world) or by resting in Lanternmere.
  Bright pips (white-gold) count double for your own school's spells.
  Gold numbers on a card = your blades/traps are boosting it right now.
  Enemy panels show which schools they are weak to / resist.
  Spells play as short cinematics. Click or press Space to skip to the hit.
  Menu > Settings > Spell animations: Cinematic or Quick.

GEAR & RARITY
  Every monster can drop gear. Rarity: Common (white), Uncommon (green),
  Rare (blue), Epic (purple), Legendary (orange). Gold-named Elite monsters
  (a star on their name) drop better gear; bosses always drop Rare or better
  and are the only source of Legendaries. Everything you wear changes how
  your wizard looks - preview it on the 3D wizard in your Backpack (B).

GRAPHICS
  Menu > Settings > Graphics: Auto, Ultra, High, Medium, Low. Auto starts at
  High and steps down if the game runs slowly. Use Low on very old laptops.

GROWING STRONGER
  When you level up, visit your school's trainer in Lanternmere to learn
  your new spells. Training points let other schools' trainers teach you
  a few of their spells. Wren and Pip can craft potions, Spell Scrolls
  and amulets from the reagents monsters drop.

FOLDERS
-------
  Play Wizzie Farm.html   the game (browser)
  desktop\                the Windows desktop app (build it: docs\DESKTOP-APP.md)
  tools\                  make-release.js (game updates for the app), Unlock All Gear
  game\data\              all game content (levels, spells, monsters, quests)
  game\js\                the engine
  docs\                   design documents, architecture, how to add levels
  tests\                  automated tests (for development)
  assets\                 reserved for future art and sound

If something breaks, a red box with the error appears in the bottom-left corner;
copy that text when reporting the bug.
